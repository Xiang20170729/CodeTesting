package main;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Arrays;
import java.util.List;

public class SudokuPuzzle {
	public static void main(String[] args) {
		
		try {
			boolean finalstate = false;
			finalstate = readfile("input_sudoku2.txt",finalstate);
			
			if(finalstate == true){
				System.out.println("False, this is not the solutions");
			}else if(finalstate == false){
				System.out.println("True, this is the solutions");
			}
			
		} catch(IOException e){
			System.out.println("Something went wrong");
			System.exit(1);
		}
		
	}

	public static boolean readfile(String filename, boolean finalstate) throws IOException {
		// TODO Auto-generated method stub
		/* read the input file */
		File file = new File(filename);
		FileReader fr = new FileReader(file);
		BufferedReader br = new BufferedReader(fr);
		
		
		String line = br.readLine();
		int leng = line.length();
		String[][] input = new String[leng][leng];
		int x = 0;
		
		/* store the input file to Array input*/
		while(line != null){
			
			if(!line.equals("")){
			
				StringBuffer sb = new StringBuffer(line);
				int y = 0;
				while(y<leng){
					input[x][y] = Character.toString(sb.charAt(y));
					y++;
				}			
				x++;
			}
			line = br.readLine();
			}
		
		/* for each row */
		String[] temp = new String[9];
		for(int row=0; row<9; row++){
			for(int col=0; col<9; col++){
				temp[col] = input[row][col];	
			}
		
			boolean ReturnResult= CompareRow(temp);
			if(ReturnResult == true){
				finalstate = true;
			}
		}
		
		/* for each column*/
		String[] temp1 = new String[9];
		for(int col=0; col<9; col++){
			for(int row=0; row<9; row++){
				temp1[row] = input[row][col];
			}
			boolean ReturnResult1 = CompareRow(temp1);
			if(ReturnResult1 == true){
				finalstate = true;
			}
		}
		
		/* for each 3*3 box*/
		String[] temp2 = new String[leng];
		for(int row=0; row<9; row=row+3){
			for(int col=0; col<9; col=col+3){
				int i=0;
				for(int row1=row; row1<row+3;row1++){
					for(int col1=col; col1<col+3;col1++){
						temp2[i] = input[row1][col1];
						i++;
						
					}
				}
				boolean ReturnResult2 = CompareRow(temp2);
				if(ReturnResult2 == true){
					finalstate = true;
				}			
			}
		}
		return finalstate;

	}

	private static boolean CompareRow(String[] temp) {
		// TODO Auto-generated method stub
		boolean state1 = false;
		boolean state2 = false;
		boolean state3 = false;
		boolean state4 = false;
		boolean state5 = false;
		boolean state6 = false;
		boolean state7 = false;
		boolean state8 = false;
		boolean state9 = false;
		boolean restate = false;
		for(int i=0;i<temp.length;i++){
			if(temp[i].equals("1")){
				if(state1 == true){
					restate = true;
				}else { state1 = true;}
			}
			if(temp[i].equals("2")){
				if(state2 == true){
					restate = true;
				}else { state2 = true;}
			}
			if(temp[i].equals("3")){
				if(state3 == true){
					restate = true;
				}else { state3 = true;}
			}
			if(temp[i].equals("4")){
				if(state4 == true){
					restate = true;
				}else { state4 = true;}
			}
			if(temp[i].equals("5")){
				if(state5 == true){
					restate = true;
				}else { state5 = true;}
			}
			if(temp[i].equals("6")){
				if(state6 == true){
					restate = true;
				}else { state6 = true;}
			}
			if(temp[i].equals("7")){
				if(state7 == true){
					restate = true;
				}else { state7 = true;}
			}
			if(temp[i].equals("8")){
				if(state8 == true){
					restate = true;
				}else { state8 = true;}
			}
			if(temp[i].equals("9")){
				if(state9 == true){
					restate = true;
				}else { state9 = true;}
			}
		}
		
	//	System.out.printf("%b_________",restate);
		return restate;
	}


}