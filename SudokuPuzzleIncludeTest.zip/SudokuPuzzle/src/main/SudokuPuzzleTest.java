package main;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;

public class SudokuPuzzleTest {

	@Test
	public void test1() throws IOException {
	//	fail("Not yet implemented");
		SudokuPuzzle puzzletest = new SudokuPuzzle();
		boolean finalstate1 = false;
		finalstate1 = puzzletest.readfile("input_sudoku.txt", finalstate1);
		assertEquals(false,finalstate1);
	}



	@Test
	public void test2() throws IOException {
		//	fail("Not yet implemented");
		SudokuPuzzle puzzletest = new SudokuPuzzle();
		boolean finalstate2 = false;
		finalstate2 = puzzletest.readfile("input_sudoku1.txt", finalstate2);
		assertEquals(false,finalstate2);
	}



	@Test
	public void test3() throws IOException {
		//	fail("Not yet implemented");
		SudokuPuzzle puzzletest = new SudokuPuzzle();
		boolean finalstate3 = false;
		finalstate3 = puzzletest.readfile("input_sudoku2.txt", finalstate3);
		assertEquals(true,finalstate3);
	}

}
